// Функция для удаления родительского элемента
function removeParent(element, levels) {
    let parent = element;
    for (let i = 0; i < levels; i++) {
        if (parent) {
            parent = parent.parentElement;
        }
    }
    if (parent) {
        parent.remove();
    }
}

// Функция для обработки узлов
function processNode(node) {
    // Проверяем наличие атрибута data-suggest-counter
    const suggestCounter = node.getAttribute("data-suggest-counter");
    if (suggestCounter && suggestCounter.startsWith("//yandex.ru/clck/safeclick")) {
        node.remove();
        return;
    }

    // Проверяем наличие класса MMSidebar-Card_bottomAdv
    if (node.classList.contains("MMSidebar-Card_bottomAdv")) {
        node.remove();
        return;
    }

    // Проверяем наличие атрибута id
    const id = node.getAttribute("id");
    if (id === "search-result-aside" || id === "click_area") {
        node.remove();
        return;
    }

    // Проверяем наличие атрибута class
    if (node.classList.contains("gcydtGWxoi")) {
        removeParent(node, 3);
        return;
    }

    // Проверяем наличие элемента с data-fullscreen-element-name
    const fullscreenElementName = node.getAttribute('data-fullscreen-element-name');
    if (fullscreenElementName === 'close-btn') {
        // Убираем overflow hidden у body
        document.body.style.overflow = '';
        // Удаляем родительский элемент на 4 уровня вверх
        removeParent(node, 4);
        return;
    }

    // Проверяем наличие iframe с указанным src
    if (node.tagName === 'IFRAME' && node.src && node.src.startsWith('https://yastatic.net/safeframe-bundles/')) {
        // Удаляем родительский элемент на 7 уровней вверх
        removeParent(node, 7);
    }
}

// Функция для обработки всех узлов, соответствующих критериям
function processMatchingNodes() {
    // Находим все узлы, соответствующие критериям
    const nodesToProcess = [
        ...document.querySelectorAll('[data-suggest-counter^="//yandex.ru/clck/safeclick"], .MMSidebar-Card_bottomAdv, #search-result-aside, #click_area, .gcydtGWxoi, [data-fullscreen-element-name="close-btn"], iframe[src^="https://yastatic.net/safeframe-bundles/"]')
    ];

    // Обрабатываем найденные узлы
    nodesToProcess.forEach(node => processNode(node));
}

// Ждем полной загрузки страницы
window.addEventListener('load', () => {
    console.log("Страница загружена");
    processMatchingNodes(); // Обрабатываем уже существующие узлы

    // Запускаем проверку новых узлов каждые 500 миллисекунд
    setInterval(processMatchingNodes, 500);
});
